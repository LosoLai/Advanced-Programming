package Assignment02;

/**@Author Arion
 * 
 */
public class GameUnexecutedException extends Exception{

	public GameUnexecutedException(String errMsg) {
		super(errMsg);
	}
}
