package Assignment02;

/**@Author Arion
 * 
 */
public class TooManyRefereeException extends Exception{

	public TooManyRefereeException(String errMsg) {
		super(errMsg);
	}
}
