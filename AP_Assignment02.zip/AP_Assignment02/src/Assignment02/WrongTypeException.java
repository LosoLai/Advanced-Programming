package Assignment02;

/**@Author Arion
 * 
 */
public class WrongTypeException extends Exception {

	public WrongTypeException(String errMsg) {
		super(errMsg);
	}
}
