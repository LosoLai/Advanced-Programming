package Assignment02;

/**@Author Arion
 * 
 */
public class TooFewAthleteException extends Exception {

	public TooFewAthleteException(String errMsg) {
		super(errMsg);
	}
}
