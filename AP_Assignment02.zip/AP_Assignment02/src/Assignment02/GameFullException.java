package Assignment02;

/**@Author Arion
 * 
 */
public class GameFullException extends Exception {
	
	public GameFullException(String errMsg) {
		super(errMsg);
	}

}
