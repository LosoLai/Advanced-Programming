package Assignment02;

/**@Author Arion
 * 
 */
public class NoRefereeException extends Exception {

	public NoRefereeException(String errMsg) {
		super(errMsg);
	}
}
