package Model;

/**Author: Loso
 * Competable is an interface 
 * Main idea: to be implemented by the Athlete class
 * therefore all athlete types 
 * have the same behaviour to compete in the games
 */
public interface Competable {
	public double Compete();
}
